# VALR Futures Grid Bot Skill

Complete grid trading bot for VALR perpetual futures. This skill provides everything needed to deploy a market-making bot with automatic stop-loss management, book reconciliation, and systemd auto-healing.

## What's Included

```
valr-futures-grid-bot/
├── SKILL.md                 # Agent skill definition (for OpenClaw)
├── README.md                # This file
├── src/
│   └── main.rs              # Bot source code (Rust)
├── Cargo.toml               # Rust dependencies
├── config/
│   └── example.json         # Example configuration
├── examples/
│   └── cancel_all.rs        # Utility to cancel all orders
└── docs/
    └── TROUBLESHOOTING.md   # Common issues & fixes
```

## Features

- **Native Stop-Loss**: Uses VALR conditional orders (`/v1/orders/conditionals`)
- **Book Reconciliation**: Health check verifies `position + bids - asks ≈ 0`
- **Auto-Healing**: systemd service with automatic restart on crash
- **Hot Reload**: Config reloaded every 5 minutes without restart
- **POST-Only Orders**: All limit orders are maker (0% fee)
- **Symmetric Sizing**: Uniform quantity per level (no drift)

## Installation

### Prerequisites

1. **Rust toolchain** (1.70+):
   ```bash
   curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
   rustup default stable
   ```

2. **VALR API credentials** stored in Alibaba Secrets Manager (or environment variables)

3. **systemd** (user session) for auto-healing

### Build

```bash
cd valr-futures-grid-bot
cargo build --release
# Binary: target/release/valr-grid-bot
```

### Configure

Edit `config/example.json` (rename to `config.json`):

```json
{
  "pair": "SOLUSDTPERP",
  "leverage": 5,
  "balance_usage_pct": 90.0,
  "levels": 3,
  "spacing_pct": 0.5,
  "max_loss_pct": 3.0
}
```

| Parameter | Description | Default |
|-----------|-------------|---------|
| `pair` | VALR futures pair | SOLUSDTPERP |
| `leverage` | Leverage multiplier | 5 |
| `balance_usage_pct` | % of USDT to deploy | 90 |
| `levels` | Grid levels per side | 3 |
| `spacing_pct` | % between levels | 0.5 |
| `max_loss_pct` | Stop-loss % from entry | 3.0 |

### Deploy

#### Option 1: systemd (recommended)

```bash
# Copy service file
cp systemd/valr-grid-bot.service ~/.config/systemd/user/

# Reload and start
systemctl --user daemon-reload
systemctl --user enable valr-grid-bot.service
systemctl --user start valr-grid-bot.service

# Check status
systemctl --user status valr-grid-bot.service

# View logs
journalctl --user -u valr-grid-bot.service -f
```

#### Option 2: Manual

```bash
cd valr-futures-grid-bot
./target/release/valr-grid-bot
```

## Usage

### Managing the Bot

```bash
# Check status
systemctl --user status valr-grid-bot.service

# Restart
systemctl --user restart valr-grid-bot.service

# Stop
systemctl --user stop valr-grid-bot.service

# Disable auto-start
systemctl --user disable valr-grid-bot.service
```

### Monitoring

```bash
# Live logs
journalctl --user -u valr-grid-bot.service -f

# Last 50 lines
journalctl --user -u valr-grid-bot.service -n 50

# Check book balance (Python)
python3 scripts/check_exposure.py
```

## How It Works

### Grid Strategy

1. Places symmetric limit orders around mid-price
2. BUY orders below, SELL orders above
3. When filled, immediately places native stop-loss
4. Opposite-side orders act as take-profit

### Health Check (every 5 min)

1. Fetches position from VALR REST API
2. Fetches open orders
3. Calculates net exposure: `position + bids - asks`
4. If unhedged:
   - Cancels all orders
   - Places emergency stop-loss
   - Places closing order at 0.5% profit
   - Logs warning with breakdown

### Auto-Healing

- systemd monitors the process
- Restarts automatically on crash (10s delay)
- Logs preserved across restarts
- No manual intervention needed

## VALR API Endpoints

| Endpoint | Purpose | Rate Limit |
|----------|---------|------------|
| `GET /v1/positions/open` | Check position | 2,000/min |
| `GET /v1/orders/open` | List orders | 2,000/min |
| `POST /v1/orders` | Place limit order | 400/s |
| `DELETE /v1/orders/order` | Cancel order | 450/s |
| `POST /v1/orders/conditionals` | Place SL | 400/s |
| `DELETE /v1/orders/conditionals` | Cancel SL | 450/s |

## Troubleshooting

### Bot not starting

```bash
# Check systemd status
systemctl --user status valr-grid-bot.service

# Check logs
journalctl --user -u valr-grid-bot.service -n 50

# Verify binary
ls -la target/release/valr-grid-bot
```

### Stale logs

If logs haven't updated in >1 min:

```bash
# Restart
systemctl --user restart valr-grid-bot.service

# Watch for errors
journalctl --user -u valr-grid-bot.service -f
```

### Stop-loss not placed

Check for:
- `BOOK IS UNHEDGED` warning in logs
- `Stop-loss placed @ X` confirmation
- `Stop-loss verified → ID` success

If missing, bot may have crashed before placement — restart.

### Build fails

```bash
# Clean and rebuild
cargo clean
cargo build --release

# Check Rust version
rustc --version  # Should be 1.70+
```

## Security

- **API keys**: Store in secrets manager, never in config files
- **Read-only preferred**: Use read-only API keys for monitoring
- **Limited scope**: Bot only needs order/trade permissions
- **No withdrawals**: Bot cannot withdraw funds

## Support

- VALR API docs: https://api-docs.rooibos.dev/
- OpenClaw docs: https://docs.openclaw.ai
- Community: https://discord.com/invite/clawd

## License

MIT — use at your own risk. Trading involves substantial risk of loss.
