# Troubleshooting Guide

## Common Issues

### 1. Bot Won't Start

**Symptoms:** systemd service fails, no logs

**Check:**
```bash
systemctl --user status valr-grid-bot.service
journalctl --user -u valr-grid-bot.service -n 50
```

**Common causes:**
- Binary not found: `ls -la target/release/valr-grid-bot`
- Config missing: `ls -la config.json`
- API keys not accessible

**Fix:**
```bash
# Rebuild
cargo build --release

# Verify config
cat config.json | jq .

# Restart
systemctl --user restart valr-grid-bot.service
```

---

### 2. Logs Are Stale

**Symptoms:** Last log entry >1 min old

**Check:**
```bash
stat logs/grid-bot.stdout | grep Modify
date
```

**Cause:** Process crashed or hung

**Fix:**
```bash
# Restart
systemctl --user restart valr-grid-bot.service

# Watch for immediate errors
journalctl --user -u valr-grid-bot.service -f
```

---

### 3. Stop-Loss Not Placed

**Symptoms:** Position open but no SL in conditional orders

**Check logs for:**
- `Stop-loss placed @ X`
- `Stop-loss verified → ID`

**Possible causes:**
- Bot crashed before SL placement
- API rate limit hit
- Signature error

**Fix:**
```bash
# Manual SL check
python3 scripts/check_sl.py

# Restart bot
systemctl --user restart valr-grid-bot.service

# Verify SL exists
python3 scripts/check_exposure.py
```

---

### 4. Book Unhedged Warning

**Symptoms:** `⚠️ BOOK IS UNHEDGED!` in logs

**This is expected** when:
- Position exists without offsetting orders
- Orders were manually cancelled
- Bot restarted mid-trade

**Bot auto-fixes:**
1. Cancels all orders
2. Places emergency stop-loss
3. Places closing order at 0.5% profit

**Verify fix:**
```bash
python3 scripts/check_exposure.py
# Should show: Hedged: True
```

---

### 5. Build Fails

**Symptoms:** `cargo build --release` errors

**Common errors:**

**`rustc` not found:**
```bash
rustup install stable
rustup default stable
```

**Dependency errors:**
```bash
cargo clean
cargo update
cargo build --release
```

**Permission denied:**
```bash
# Ensure you own the directory
chown -R $USER:$USER ~/bots/valr-grid-bot
```

---

### 6. systemd Service Fails

**Symptoms:** `Active: failed` or `activating (auto-restart)`

**Check:**
```bash
systemctl --user status valr-grid-bot.service
journalctl --user -u valr-grid-bot.service -n 100
```

**Common fixes:**

**Exit code 216 (GROUP):**
- Edit service file, remove `User=admin` line
- Reload: `systemctl --user daemon-reload`

**Exit code 1 (panic):**
- Check logs for Rust panic message
- Likely config or API issue
- Fix root cause, then restart

**Timeout:**
- Increase `TimeoutStartSec=60` in service file
- Network may be slow

---

### 7. Orders Not Placing

**Symptoms:** Bot running but no orders on VALR

**Check:**
```bash
# Verify API keys work
python3 scripts/test_api.py

# Check logs for errors
journalctl --user -u valr-grid-bot.service | grep -i error
```

**Possible causes:**
- Insufficient balance (need $10+ USDT)
- API key permissions wrong
- Rate limited (30/min public, 2000/min auth)

---

### 8. Position Not Detected

**Symptoms:** Bot says "No existing position" but position exists on VALR

**Cause:** Startup race condition — position opened before bot started

**Fix:** Bot now fetches from REST API on startup. If still failing:

```bash
# Manual check
python3 -c "
import subprocess, requests, hmac, hashlib, time
key = subprocess.check_output(['python3', '/home/admin/.openclaw/secrets/secrets.py', 'get', 'valr_api_key']).decode().strip()
secret = subprocess.check_output(['python3', '/home/admin/.openclaw/secrets/secrets.py', 'get', 'valr_api_secret']).decode().strip()
ts = str(int(time.time() * 1000))
sig = hmac.new(secret.encode(), (ts + 'GET' + '/v1/positions/open').encode(), hashlib.sha512).hexdigest()
r = requests.get('https://api.valr.com/v1/positions/open', headers={'X-VALR-API-KEY': key, 'X-VALR-SIGNATURE': sig, 'X-VALR-TIMESTAMP': ts})
print(r.json())
"
```

---

## Getting Help

1. **Check logs first** — 90% of issues are obvious in logs
2. **Verify API access** — Most issues are auth/permissions
3. **Restart service** — Auto-healing fixes transient issues
4. **Check VALR status** — Exchange may be down

### Log Patterns

| Log Message | Meaning | Action |
|-------------|---------|--------|
| `✅ Stop-loss verified` | SL placed successfully | None |
| `⚠️ BOOK IS UNHEDGED` | Exposure mismatch | Bot auto-fixes |
| `❌ Stop-loss failed` | SL placement error | Restart bot |
| `429 Too Many Requests` | Rate limited | Wait 1 min |
| `WS closed` | WebSocket disconnected | Auto-reconnects |

### When to Ask for Help

- Repeated crashes after restart
- Funds missing (check VALR directly first)
- API returns 403/401 consistently
- Build fails with unknown errors

---

## Quick Reference

```bash
# Status
systemctl --user status valr-grid-bot.service

# Logs
journalctl --user -u valr-grid-bot.service -f

# Restart
systemctl --user restart valr-grid-bot.service

# Stop
systemctl --user stop valr-grid-bot.service

# Check exposure
python3 scripts/check_exposure.py
```
