/// VALR Futures Grid Bot v2
///
/// Strategy: Place symmetric grid of limit orders. On fill, immediately place
/// native VALR stop-loss order. Trail stop as position profits.
///
/// Key features:
/// - POST-ONLY limit orders → 0% maker fee
/// - Native stop-loss via conditional orders (VALR monitors, not us)
/// - Stop trails on profitable fills
/// - Config hot-reload every 5 min (only if grid is stale)
/// - Startup safety: detects existing positions/orders, doesn't double-up

use anyhow::Result;
use rust_decimal::prelude::*;
use rust_decimal::Decimal;
use tokio::sync::mpsc;
use tracing::{info, warn, error};

use valr_common::{
    AccountStream, Credentials, FillEvent, TradeStream, ValrClient,
};

// ──────────────────────────────────────────────
// Config
// ──────────────────────────────────────────────

#[derive(Debug, Clone)]
pub struct GridConfig {
    pub pair: String,
    pub leverage: u32,
    pub balance_usage: Decimal,
    pub levels: usize,
    pub spacing_pct: Decimal,
    pub max_loss_pct: Decimal,
}

fn load_config() -> Result<GridConfig> {
    let exe_path = std::env::current_exe()?;
    let bin_dir = exe_path.parent().ok_or_else(|| anyhow::anyhow!("Cannot determine binary directory"))?;
    let config_path = bin_dir.join("config.json");
    let config_path = if config_path.exists() { config_path } else { std::env::current_dir()?.join("config.json") };
    
    let raw = std::fs::read_to_string(&config_path)
        .map_err(|e| anyhow::anyhow!("Cannot read config.json at {}: {}", config_path.display(), e))?;

    let stripped: String = raw.lines()
        .map(|line| {
            if let Some(idx) = line.find("//") {
                let before = &line[..idx];
                if before.chars().filter(|&c| c == '"').count() % 2 == 0 {
                    return before.trim_end().to_string();
                }
            }
            line.to_string()
        })
        .collect::<Vec<_>>()
        .join("\n");

    let v: serde_json::Value = serde_json::from_str(&stripped)
        .map_err(|e| anyhow::anyhow!("config.json parse error: {}", e))?;

    let usage_pct = v["balance_usage_pct"].as_f64().unwrap_or(90.0).clamp(1.0, 100.0);

    Ok(GridConfig {
        pair:                 v["pair"].as_str().unwrap_or("SOLUSDTPERP").to_string(),
        leverage:             v["leverage"].as_u64().unwrap_or(5) as u32,
        balance_usage:        Decimal::from_f64(usage_pct / 100.0).unwrap_or(Decimal::new(9, 1)),
        levels:               v["levels"].as_u64().unwrap_or(3) as usize,
        spacing_pct:          Decimal::from_f64(v["spacing_pct"].as_f64().unwrap_or(0.5)).unwrap_or(Decimal::new(5, 1)),
        max_loss_pct:         Decimal::from_f64(v["max_loss_pct"].as_f64().unwrap_or(3.0)).unwrap_or(Decimal::new(3, 0)),
    })
}

// ──────────────────────────────────────────────
// Grid state
// ──────────────────────────────────────────────

#[derive(Debug)]
struct GridLevel {
    price: Decimal,
    order_id: Option<String>,
    side: String,
}

struct GridBot {
    config: GridConfig,
    client: ValrClient,
    levels: Vec<GridLevel>,
    mid_price: Decimal,
    initial_margin: Decimal,
    cycle_count: u64,
    price: TradeStream,
    fills: mpsc::Receiver<FillEvent>,
    // Position tracking
    position_qty: Decimal,
    avg_entry: Decimal,
    stop_order_id: Option<String>,
    peak_pnl: Decimal,
    // Re-centre tracking
    last_fill_time: Option<std::time::Instant>,
    grid_placed: bool,
}

impl GridBot {
    fn new(
        config: GridConfig,
        client: ValrClient,
        price: TradeStream,
        fills: mpsc::Receiver<FillEvent>,
    ) -> Self {
        Self {
            config,
            client,
            levels: Vec::new(),
            mid_price: Decimal::ZERO,
            initial_margin: Decimal::ZERO,
            cycle_count: 0,
            price,
            fills,
            position_qty: Decimal::ZERO,
            avg_entry: Decimal::ZERO,
            stop_order_id: None,
            peak_pnl: Decimal::ZERO,
            last_fill_time: None,
            grid_placed: false,
        }
    }

    async fn current_price(&self) -> Result<Decimal> {
        if let Some(p) = self.price.mid_now() {
            return Ok(p);
        }
        info!("WS price not available, falling back to REST");
        if let Ok(v) = self.client.get(&format!("/v1/public/{}/markprice", self.config.pair)).await {
            if let Some(p) = v["markPrice"].as_str().and_then(|s| Decimal::from_str(s).ok()) {
                return Ok(p);
            }
        }
        anyhow::bail!("No price from WS or REST")
    }

    fn grid_prices(&self, mid: Decimal) -> Vec<(String, Decimal)> {
        let spacing = mid * self.config.spacing_pct / Decimal::new(100, 0);
        let mut out = Vec::new();
        for i in 1..=self.config.levels {
            out.push(("BUY".into(), mid - spacing * Decimal::new(i as i64, 0)));
        }
        for i in 1..=self.config.levels {
            out.push(("SELL".into(), mid + spacing * Decimal::new(i as i64, 0)));
        }
        out
    }

    fn tick_dp(&self) -> u32 {
        if self.config.pair.starts_with("BTC") { 0 } else { 2 }
    }

    fn uniform_qty(&self, mid: Decimal, usable: Decimal) -> Decimal {
        let levels = Decimal::new(self.config.levels as i64, 0);
        let notional_per_level = usable / levels;
        let leveraged = notional_per_level * Decimal::from(self.config.leverage);
        let dp = if self.config.pair.starts_with("BTC") { 4 } else { 2 };
        (leveraged / mid).round_dp(dp)
    }

    /// Cancel all existing stop-loss conditionals for this pair
    async fn cancel_all_stop_losses(&mut self) -> Result<()> {
        let conditionals = self.client.get("/v1/orders/conditionals").await?;
        if let Some(arr) = conditionals.as_array() {
            for cond in arr {
                let pair = cond["currencyPair"].as_str().or_else(|| cond["pair"].as_str());
                let cond_type = cond["conditionalType"].as_str();
                if pair == Some(&self.config.pair) && cond_type == Some("STOP_LOSS") {
                    if let Some(id) = cond["orderId"].as_str().or_else(|| cond["id"].as_str()) {
                        // Use DELETE /v1/orders/conditionals/{id} with body
                        let body = serde_json::json!({
                            "orderId": id,
                            "currencyPair": self.config.pair
                        });
                        match self.client.delete("/v1/orders/conditionals", &body).await {
                            Ok(_) => info!("  Cancelled old SL: {}", &id[..8]),
                            Err(e) => warn!("  Failed to cancel SL {}: {}", &id[..8], e),
                        }
                        tokio::time::sleep(tokio::time::Duration::from_millis(100)).await;
                    }
                }
            }
        }
        self.stop_order_id = None;
        Ok(())
    }

    /// Place native VALR stop-loss order for current position
    async fn place_stop_loss(&mut self, stop_price: Decimal) -> Result<()> {
        // Cancel ALL existing stop-losses for this pair (not just the one we track)
        self.cancel_all_stop_losses().await?;

        if self.position_qty == Decimal::ZERO {
            return Ok(());
        }

        // Round stop price to tick size (SOL = 2dp, BTC = 0dp)
        let tick_dp = if self.config.pair.starts_with("BTC") { 0 } else { 2 };
        let stop_price_rounded = stop_price.round_dp(tick_dp);

        let is_long = self.position_qty > Decimal::ZERO;
        let stop_side = if is_long { "SELL" } else { "BUY" };
        
        // Use quantity = "0" to close entire position (futures TP/SL convention)
        // Note: futures don't use "side" parameter - VALR infers from existing position
        info!("🛡️  Placing {} stop-loss: qty=0 (full position) @ trigger={} (rounded to {}dp)", 
              self.config.pair, stop_price_rounded, tick_dp);

        let payload = serde_json::json!({
            "quantity": "0",
            "pair": self.config.pair,
            "triggerType": "MARK_PRICE",
            "stopLossTriggerPrice": stop_price_rounded.to_string(),
            "stopLossOrderPrice": "-1"
        });

        match self.client.post("/v1/orders/conditionals", &payload).await {
            Ok(resp) => {
                // VALR returns orderId in response
                let id = resp["id"].as_str()
                    .or_else(|| resp["orderId"].as_str())
                    .or_else(|| resp["conditionalOrderId"].as_str())
                    .map(|s| s.to_string());
                
                if let Some(order_id) = id {
                    // Verify by listing conditionals and checking if our order exists
                    tokio::time::sleep(tokio::time::Duration::from_millis(300)).await;
                    match self.client.get("/v1/orders/conditionals").await {
                        Ok(orders) => {
                            if let Some(arr) = orders.as_array() {
                                let found = arr.iter().any(|o| {
                                    o["orderId"].as_str() == Some(&order_id) ||
                                    o["id"].as_str() == Some(&order_id)
                                });
                                if found {
                                    let id_short = if order_id.len() >= 8 { &order_id[..8] } else { &order_id };
                                    info!("✅ Stop-loss verified → {}", id_short);
                                    self.stop_order_id = Some(order_id);
                                    return Ok(());
                                }
                            }
                        }
                        Err(e) => warn!("Order list fetch failed: {}", e),
                    }
                    warn!("⚠️  Stop-loss returned ID but not found in list — may have failed");
                } else {
                    warn!("⚠️  Stop-loss response missing order ID: {:?}", resp);
                }
                Err(anyhow::anyhow!("Stop-loss placement unverified"))
            }
            Err(e) => {
                warn!("❌ Stop-loss placement failed: {}", e);
                Err(e)
            }
        }
    }

    /// Calculate stop price: fixed % from average entry
    fn calc_stop_price(&mut self, _current_price: Decimal) -> Decimal {
        if self.position_qty == Decimal::ZERO || self.avg_entry == Decimal::ZERO {
            return Decimal::ZERO;
        }

        let is_long = self.position_qty > Decimal::ZERO;
        let stop_distance = self.avg_entry * self.config.max_loss_pct / Decimal::new(100, 0);
        
        if is_long {
            self.avg_entry - stop_distance
        } else {
            self.avg_entry + stop_distance
        }
    }

    /// Check for existing position on startup and place stop-loss if needed
    async fn check_existing_position(&mut self) -> Result<bool> {
        let positions = self.client.get("/v1/positions/open").await?;
        
        if let Some(arr) = positions.as_array() {
            for pos in arr {
                let pair = pos["pair"].as_str().or_else(|| pos["currencyPair"].as_str());
                if pair == Some(&self.config.pair) {
                    let qty: Decimal = pos["quantity"].as_str()
                        .and_then(|s| Decimal::from_str(s).ok())
                        .unwrap_or(Decimal::ZERO);
                    
                    if qty > Decimal::ZERO {
                        let side = pos["side"].as_str().unwrap_or("buy");
                        let entry: Decimal = pos["entryPrice"].as_str()
                            .and_then(|s| Decimal::from_str(s).ok())
                            .unwrap_or(Decimal::ZERO);
                        
                        // VALR returns "buy" or "sell" for side
                        self.position_qty = if side == "buy" { qty } else { -qty };
                        
                        let current_price = self.current_price().await?;
                        
                        // If entry price is missing/zero, use current price as fallback
                        if entry > Decimal::ZERO {
                            self.avg_entry = entry;
                            info!("📊 Found existing position: {} {} @ entry {}", 
                                  qty, self.config.pair, entry);
                        } else {
                            self.avg_entry = current_price;
                            info!("📊 Found existing position: {} {} (entry unknown, using current price {})", 
                                  qty, self.config.pair, current_price);
                        }
                        
                        let stop_price = self.calc_stop_price(current_price);
                        
                        match self.place_stop_loss(stop_price).await {
                            Ok(_) => {
                                info!("✅ Stop-loss placed for existing position @ {}", stop_price);
                                return Ok(true);
                            }
                            Err(e) => {
                                warn!("❌ Failed to place stop-loss for existing position: {}", e);
                                return Ok(false);
                            }
                        }
                    }
                }
            }
        }
        
        Ok(false)
    }

    async fn place_grid(&mut self) -> Result<()> {
        let mid = self.current_price().await?;
        let available = self.client.get_usdt_balance().await?;
        let usable = (available * self.config.balance_usage).round_dp(2);

        info!(
            "Mid: {} | Available: {} USDT | Deploying: {} ({:.0}%)",
            mid, available, usable,
            self.config.balance_usage * Decimal::new(100, 0)
        );
        if usable < Decimal::new(1, 0) {
            warn!("Insufficient balance to place grid");
            return Ok(());
        }

        self.mid_price = mid;
        if self.initial_margin == Decimal::ZERO {
            self.initial_margin = usable;
        }
        self.levels.clear();

        let qty = self.uniform_qty(mid, usable);
        let tick_dp = self.tick_dp();
        info!("Placing {} orders around {} (qty={} each)", self.config.levels * 2, mid, qty);

        for (side, raw_price) in self.grid_prices(mid) {
            let price = raw_price.round_dp(tick_dp);
            match self.client.place_limit_order(&self.config.pair, &side, &price.to_string(), &qty.to_string(), true).await {
                Ok(id) => {
                    info!("✅ {} @ {} → {}", side, price, &id[..8]);
                    self.levels.push(GridLevel { price: raw_price, order_id: Some(id), side });
                }
                Err(e) => warn!("Failed to place {} @ {}: {}", side, price, e),
            }
            tokio::time::sleep(tokio::time::Duration::from_millis(100)).await;
        }

        info!("Grid live: {} orders", self.levels.len());
        self.grid_placed = true;
        Ok(())
    }

    async fn handle_fill(&mut self, fill: &FillEvent) -> Result<()> {
        let fill_qty = fill.filled_qty;
        let fill_price = fill.price;
        let is_buy = fill.side.to_lowercase() == "buy";

        info!("📥 Fill: {} {} @ {} (side={})", fill_qty, self.config.pair, fill_price, fill.side);
        
        self.last_fill_time = Some(std::time::Instant::now());

        let qty_signed = if is_buy { fill_qty } else { -fill_qty };
        
        // Track whether we're opening a new position (for setting avg_entry)
        let was_flat = self.position_qty == Decimal::ZERO;
        
        if (self.position_qty > Decimal::ZERO && qty_signed > Decimal::ZERO) ||
           (self.position_qty < Decimal::ZERO && qty_signed < Decimal::ZERO) {
            // Adding to existing position in same direction → update weighted avg
            let total_value = (self.position_qty.abs() * self.avg_entry) + (fill_qty * fill_price);
            self.position_qty += qty_signed;
            self.avg_entry = total_value / self.position_qty.abs();
        } else {
            // Reducing position or opening new position from flat
            self.position_qty += qty_signed;
            
            // If we were flat and now have a position, this fill opened it → set avg_entry
            if was_flat && self.position_qty != Decimal::ZERO {
                self.avg_entry = fill_price;
                info!("📊 New position opened: {} {} @ {}", self.position_qty, self.config.pair, fill_price);
            }
            
            // Check if position closed (crossed through zero)
            if self.position_qty.abs() < Decimal::from_str("0.001").unwrap() {
                info!("✅ Position closed");
                self.position_qty = Decimal::ZERO;
                self.avg_entry = Decimal::ZERO;
                self.peak_pnl = Decimal::ZERO;
                if let Some(ref id) = self.stop_order_id {
                    let _ = self.client.delete(&format!("/v1/orders/conditionals/conditional/{}", id), &serde_json::json!({})).await;
                    self.stop_order_id = None;
                }
            }
        }

        if let Some(idx) = self.levels.iter().position(|l| l.order_id.as_deref() == Some(&fill.order_id)) {
            let raw_price = self.levels[idx].price;
            let side = &self.levels[idx].side;
            let qty = self.uniform_qty(self.mid_price, self.initial_margin);
            let tick_dp = self.tick_dp();
            let price = raw_price.round_dp(tick_dp);

            match self.client.place_limit_order(&self.config.pair, side, &price.to_string(), &qty.to_string(), true).await {
                Ok(id) => {
                    info!("✅ Replacement {} @ {} → {}", side, price, &id[..8]);
                    self.levels[idx].order_id = Some(id);
                }
                Err(e) => warn!("Replacement failed {} @ {}: {}", side, price, e),
            }
        }

        if self.position_qty != Decimal::ZERO {
            let current_price = self.current_price().await?;
            let stop_price = self.calc_stop_price(current_price);
            match self.place_stop_loss(stop_price).await {
                Ok(_) => info!("🛡️  Stop-loss updated: {} @ {}", self.position_qty, stop_price),
                Err(e) => error!("❌ Stop-loss placement failed: {}", e),
            }
            
            info!("📊 Position: qty={} | avg_entry={} | stop={}", 
                  self.position_qty, self.avg_entry, stop_price);
        } else {
            info!("📊 No position — no stop-loss needed");
        }

        Ok(())
    }

    async fn cancel_all(&mut self) -> Result<()> {
        info!("Cancelling all open orders...");
        
        // Fetch actual open orders from exchange (not just cached levels)
        let orders = self.client.get(&format!("/v1/orders/open?currencyPair={}", self.config.pair)).await?;
        if let Some(arr) = orders.as_array() {
            for order in arr {
                if let Some(id) = order["orderId"].as_str().or_else(|| order["id"].as_str()) {
                    match self.client.cancel_order(&self.config.pair, id).await {
                        Ok(_) => info!("  Cancelled {}", &id[..8]),
                        Err(e) => warn!("  Cancel failed {}: {}", &id[..8], e),
                    }
                    tokio::time::sleep(tokio::time::Duration::from_millis(50)).await;
                }
            }
        }
        
        // Also clear cached levels
        self.levels.clear();
        Ok(())
    }

    fn print_status(&self) {
        info!("──────────────────────────────────────");
        info!("Grid Bot — {} | Cycle {}", self.config.pair, self.cycle_count);
        info!("Active levels: {}", self.levels.len());
        if self.position_qty != Decimal::ZERO {
            info!("Position: {} {} @ avg {}", self.position_qty, self.config.pair, self.avg_entry);
            info!("Stop-loss: {:?}", self.stop_order_id);
        }
        for l in &self.levels {
            let s = if l.order_id.is_some() { "LIVE" } else { "FILLED" };
            info!("  {} {} @ {:.2}", s, l.side, l.price);
        }
        info!("──────────────────────────────────────");
    }
}

// ──────────────────────────────────────────────
// Main
// ──────────────────────────────────────────────

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt().with_target(false).with_level(true).init();
    info!("🤖 Herman's VALR Grid Bot v2 starting...");

    let creds = Credentials::load()?;
    let client = ValrClient::new(creds.clone());

    let config = load_config()?;

    // Check for existing position FIRST — we need to manage it even with low balance
    let mut has_existing_position = false;
    match client.get("/v1/positions/open").await {
        Ok(positions) => {
            if let Some(arr) = positions.as_array() {
                for pos in arr {
                    let pair = pos["pair"].as_str().or_else(|| pos["currencyPair"].as_str());
                    if pair == Some(&config.pair) {
                        let qty: Decimal = pos["quantity"].as_str()
                            .and_then(|s| Decimal::from_str(s).ok())
                            .unwrap_or(Decimal::ZERO);
                        if qty > Decimal::ZERO {
                            let side = pos["side"].as_str().unwrap_or("buy");
                            let signed_qty = if side == "buy" { qty } else { -qty };
                            has_existing_position = true;
                            info!("📊 Found existing position on startup: {} {} (side: {}) @ {}",
                                  signed_qty, config.pair, side,
                                  pos["entryPrice"].as_str().unwrap_or("unknown"));
                        }
                    }
                }
            }
        }
        Err(e) => warn!("Failed to check positions on startup: {}", e),
    }

    let balances = client.get_balances().await?;
    info!("Connected. Balances:");
    for b in &balances {
        let total: Decimal = b.total.parse().unwrap_or(Decimal::ZERO);
        if total > Decimal::ZERO {
            info!("  {} — available: {} total: {}", b.currency, b.available, b.total);
        }
    }

    let usdt_available = balances.iter()
        .find(|b| b.currency == "USDT")
        .and_then(|b| b.available.parse::<Decimal>().ok())
        .unwrap_or(Decimal::ZERO);

    // Check for existing grid orders (they tie up margin, reducing available balance)
    let mut has_existing_orders = false;
    match client.get(&format!("/v1/orders/open?currencyPair={}", config.pair)).await {
        Ok(orders) => {
            if let Some(arr) = orders.as_array() {
                if arr.len() > 0 {
                    has_existing_orders = true;
                    info!("📊 Found {} existing grid orders on startup", arr.len());
                }
            }
        }
        Err(e) => warn!("Failed to check orders on startup: {}", e),
    }

    // Only require $10 if we don't have existing state to manage
    if usdt_available < Decimal::new(10, 0) && !has_existing_position && !has_existing_orders {
        warn!("⚠️  Low USDT balance: {} available. Need at least $10.", usdt_available);
        warn!("   Please transfer USDT to this subaccount first.");
        warn!("   Exiting. Re-run after funding.");
        return Ok(());
    } else if usdt_available < Decimal::new(10, 0) {
        info!("📊 Managing existing state with low balance ({} USDT available)", usdt_available);
    }
    info!("Config: {} | {}x leverage | {}% balance | {} levels | {}% spacing | max_loss={}%",
          config.pair, config.leverage,
          config.balance_usage * Decimal::new(100, 0),
          config.levels, config.spacing_pct, config.max_loss_pct);

    let price = TradeStream::spawn(&config.pair);
    let fills = AccountStream::spawn(creds);

    info!("Waiting for WS price feed...");
    match price.mid_wait(tokio::time::Duration::from_secs(10)).await {
        Some(p) => info!("✅ WS price live: {}", p),
        None    => warn!("WS price timeout — will use REST fallback"),
    }

    let mut bot = GridBot::new(config, client, price, fills);

    // ──────────────────────────────────────────────
    // Startup safety checks
    // ──────────────────────────────────────────────
    
    let mut has_position = false;
    let mut order_count = 0;
    
    // Check for existing position and place stop-loss if found
    match bot.check_existing_position().await {
        Ok(true) => {
            has_position = true;
            info!("✅ Existing position found and stop-loss placed");
        }
        Ok(false) => {
            info!("No existing position");
        }
        Err(e) => {
            warn!("Failed to check existing position: {}", e);
        }
    }
    
    // Also check position count for order placement logic
    let positions = bot.client.get("/v1/positions/open").await?;
    if let Some(arr) = positions.as_array() {
        for pos in arr {
            let pair = pos["pair"].as_str().or_else(|| pos["currencyPair"].as_str());
            if pair == Some(&bot.config.pair) {
                let qty: Decimal = pos["quantity"].as_str()
                    .and_then(|s| Decimal::from_str(s).ok())
                    .unwrap_or(Decimal::ZERO);
                if qty > Decimal::ZERO && !has_position {
                    has_position = true;
                    warn!("⚠️  Position detected but stop-loss placement may have failed");
                }
            }
        }
    }
    
    // Check for existing orders
    let orders = bot.client.get(&format!("/v1/orders/open?currencyPair={}", bot.config.pair)).await?;
    order_count = orders.as_array().map(|a| a.len()).unwrap_or(0);
    if order_count > 0 {
        error!("🚨 {} OPEN ORDERS DETECTED ON STARTUP!", order_count);
        error!("   Bot will NOT place new orders. Waiting for re-centre to handle cleanup.");
    }
    
    // Main event loop
    let mut recentre = tokio::time::interval(tokio::time::Duration::from_secs(300));
    recentre.tick().await;
    
    loop {
        // Initial grid placement (only if no existing state)
        if !has_position && order_count == 0 && !bot.grid_placed {
            let mut placed = false;
            for attempt in 1..=5u32 {
                match bot.place_grid().await {
                    Ok(_) => { placed = true; break; }
                    Err(e) => {
                        let wait = if e.to_string().contains("429") { 30u64 } else { (attempt * 5) as u64 };
                        warn!("Grid placement {}/5 failed: {}. Retry in {}s...", attempt, e, wait);
                        tokio::time::sleep(tokio::time::Duration::from_secs(wait)).await;
                    }
                }
            }
            if !placed {
                error!("Grid failed after 5 attempts. Exiting.");
                return Ok(());
            }
            bot.print_status();
        } else if has_position || order_count > 0 {
            info!("📊 Existing state detected — will manage on first health check");
        }
        
        // Event loop
        tokio::select! {
            Some(fill) = bot.fills.recv() => {
                if fill.pair == bot.config.pair {
                    if let Err(e) = bot.handle_fill(&fill).await {
                        warn!("Fill handler error: {}", e);
                    }
                }
            }
            _ = recentre.tick() => {
                info!("⟳ Health check timer fired...");
                
                // Check current state from exchange (not just cached variables)
                let current_positions = bot.client.get("/v1/positions/open").await.unwrap_or(serde_json::json!([]));
                let has_open_position = current_positions.as_array().map(|arr| {
                    arr.iter().any(|p| {
                        let pair = p["pair"].as_str().or_else(|| p["currencyPair"].as_str());
                        let qty: Decimal = p["quantity"].as_str()
                            .and_then(|s| Decimal::from_str(s).ok())
                            .unwrap_or(Decimal::ZERO);
                        pair == Some(&bot.config.pair) && qty > Decimal::ZERO
                    })
                }).unwrap_or(false);
                
                // POSITION OPEN: Only manage stop-loss. Grid orders are take-profit — leave them!
                if has_open_position {
                    info!("📊 Position open — managing stop-loss only (grid orders are take-profit)");
                    
                    // Sync position from VALR if our in-memory state is stale (e.g., fill happened before bot started)
                    if bot.position_qty == Decimal::ZERO {
                        for pos in current_positions.as_array().unwrap_or(&vec![]) {
                            let pair = pos["pair"].as_str().or_else(|| pos["currencyPair"].as_str());
                            if pair == Some(&bot.config.pair) {
                                let qty: Decimal = pos["quantity"].as_str()
                                    .and_then(|s| Decimal::from_str(s).ok())
                                    .unwrap_or(Decimal::ZERO);
                                if qty > Decimal::ZERO {
                                    let side = pos["side"].as_str().unwrap_or("buy");
                                    let entry: Decimal = pos["entryPrice"].as_str()
                                        .and_then(|s| Decimal::from_str(s).ok())
                                        .unwrap_or(Decimal::ZERO);
                                    bot.position_qty = if side == "buy" { qty } else { -qty };
                                    bot.avg_entry = entry;
                                    info!("🔄 Synced position from VALR: {} {} @ entry {}", bot.position_qty, bot.config.pair, entry);
                                    break;
                                }
                            }
                        }
                    }
                    
                    // Fetch open orders for reconciliation
                    let current_orders = bot.client.get(&format!("/v1/orders/open?currencyPair={}", bot.config.pair)).await.unwrap_or(serde_json::json!([]));
                    
                    // Calculate net exposure: position + bids - asks should = 0
                    let mut bid_qty = Decimal::ZERO;
                    let mut ask_qty = Decimal::ZERO;
                    if let Some(arr) = current_orders.as_array() {
                        for o in arr {
                            let qty: Decimal = o["remainingQuantity"].as_str()
                                .and_then(|s| Decimal::from_str(s).ok())
                                .unwrap_or(Decimal::ZERO);
                            if o["side"].as_str() == Some("buy") {
                                bid_qty += qty;
                            } else if o["side"].as_str() == Some("sell") {
                                ask_qty += qty;
                            }
                        }
                    }
                    
                    // Net exposure: long position is positive, short is negative
                    // Bids add to long exposure, asks add to short exposure
                    // For a hedged book: position_qty + bid_qty - ask_qty should ≈ 0
                    let net_exposure = bot.position_qty + bid_qty - ask_qty;
                    let is_hedged = net_exposure.abs() < Decimal::from_str("0.01").unwrap();
                    
                    if !is_hedged {
                        warn!("⚠️  BOOK IS UNHEDGED! Net exposure: {} (position={}, bids={}, asks={})", 
                              net_exposure, bot.position_qty, bid_qty, ask_qty);
                        warn!("   Cancelling all orders and placing protective orders...");
                        
                        // Cancel all orders
                        bot.cancel_all().await?;
                        tokio::time::sleep(tokio::time::Duration::from_millis(500)).await;
                        
                        // Fetch actual position from REST to get accurate entry price
                        let positions = bot.client.get("/v1/positions/open").await.unwrap_or(serde_json::json!([]));
                        let mut position_entry: Option<Decimal> = None;
                        if let Some(arr) = positions.as_array() {
                            for pos in arr {
                                let pair = pos["pair"].as_str().or_else(|| pos["currencyPair"].as_str());
                                if pair == Some(&bot.config.pair) {
                                    if let Some(entry) = pos["entryPrice"].as_str().and_then(|s| Decimal::from_str(s).ok()) {
                                        if entry > Decimal::ZERO {
                                            position_entry = Some(entry);
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        
                        let base_price = position_entry.unwrap_or(bot.avg_entry);
                        
                        // Place stop-loss for the position
                        let current_price = bot.current_price().await.unwrap_or(bot.mid_price);
                        let stop_price = bot.calc_stop_price(current_price);
                        match bot.place_stop_loss(stop_price).await {
                            Ok(_) => info!("✅ Emergency stop-loss placed @ {}", stop_price),
                            Err(e) => error!("❌ Emergency stop-loss failed: {}", e),
                        }
                        
                        // Place closing limit order 0.5% in profit direction (reduce-only, natural exit)
                        if bot.position_qty != Decimal::ZERO && base_price > Decimal::ZERO {
                            let is_long = bot.position_qty > Decimal::ZERO;
                            let close_side = if is_long { "SELL" } else { "BUY" };
                            // 0.5% in profit direction from actual entry price
                            let profit_price = if is_long {
                                base_price * Decimal::from_str("1.005").unwrap()
                            } else {
                                base_price * Decimal::from_str("0.995").unwrap()
                            };
                            let tick_dp = bot.tick_dp();
                            let profit_price = profit_price.round_dp(tick_dp);
                            let close_qty = bot.position_qty.abs();
                            
                            info!("🎯 Placing closing {} order: {} @ {} (0.5% profit, entry={})", 
                                  close_side, close_qty, profit_price, base_price);
                            
                            match bot.client.place_limit_order(&bot.config.pair, close_side, &profit_price.to_string(), &close_qty.to_string(), true).await {
                                Ok(id) => info!("✅ Closing order placed → {}", &id[..8]),
                                Err(e) => warn!("❌ Closing order failed: {}", e),
                            }
                        } else if bot.position_qty != Decimal::ZERO {
                            warn!("⚠️  Cannot place closing order: entry price unknown (position={}, base_price={})", 
                                  bot.position_qty, base_price);
                        }
                        
                        has_position = true;
                        continue;
                    }
                    
                    // Book is hedged — just ensure stop-loss is in place
                    if bot.position_qty != Decimal::ZERO && bot.stop_order_id.is_none() {
                        let current_price = bot.current_price().await.unwrap_or(bot.mid_price);
                        let stop_price = bot.calc_stop_price(current_price);
                        match bot.place_stop_loss(stop_price).await {
                            Ok(_) => info!("✅ Stop-loss placed @ {}", stop_price),
                            Err(e) => error!("❌ Stop-loss failed: {}", e),
                        }
                    }
                    has_position = true;
                    continue;
                }
                
                // No position — fetch order count and clean up old grid
                let current_orders = bot.client.get(&format!("/v1/orders/open?currencyPair={}", bot.config.pair)).await.unwrap_or(serde_json::json!([]));
                let order_count_now = current_orders.as_array().map(|a| a.len()).unwrap_or(0);
                
                if order_count_now > 0 {
                    info!("🧹 No position but {} old orders exist — cleaning up...", order_count_now);
                    bot.cancel_all().await?;
                    tokio::time::sleep(tokio::time::Duration::from_millis(500)).await;
                }
                
                // Normal re-centre flow (no position)
                if !bot.grid_placed {
                    info!("Grid not yet placed — skipping re-centre");
                    continue;
                }
                
                if let Some(last_fill) = bot.last_fill_time {
                    if last_fill.elapsed().as_secs() < 300 {
                        info!("Recent fill ({:.0}s ago) — skipping re-centre", last_fill.elapsed().as_secs());
                        continue;
                    }
                }
                
                // Re-centre: cancel and re-place grid with updated config
                info!("⟳ Re-centring grid (config check)...");
                bot.cancel_all().await?;
                bot.grid_placed = false;
                match load_config() {
                    Ok(new_cfg) => {
                        info!("Config reloaded: {}x leverage | {}% balance | {} levels | {}% spacing",
                            new_cfg.leverage,
                            new_cfg.balance_usage * Decimal::new(100, 0),
                            new_cfg.levels, new_cfg.spacing_pct);
                        bot.config = new_cfg;
                    }
                    Err(e) => warn!("Config reload failed (keeping current): {}", e),
                }
                
                // Place fresh grid (no position, cleaned up old orders)
                let mut placed = false;
                for attempt in 1..=5u32 {
                    match bot.place_grid().await {
                        Ok(_) => { placed = true; break; }
                        Err(e) => {
                            let wait = if e.to_string().contains("429") { 30u64 } else { (attempt * 5) as u64 };
                            warn!("Grid placement {}/5 failed: {}. Retry in {}s...", attempt, e, wait);
                            tokio::time::sleep(tokio::time::Duration::from_secs(wait)).await;
                        }
                    }
                }
                if placed {
                    bot.print_status();
                }
            }
        }
    }
}
