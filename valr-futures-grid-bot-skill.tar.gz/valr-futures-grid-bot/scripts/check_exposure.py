#!/usr/bin/env python3
"""Check VALR grid bot exposure — verifies book is hedged."""

import subprocess
import requests
import hmac
import hashlib
import time
import json
from urllib.parse import urlencode

def get_creds():
    key = subprocess.check_output(["python3", "/home/admin/.openclaw/secrets/secrets.py", "get", "valr_api_key"]).decode().strip()
    secret = subprocess.check_output(["python3", "/home/admin/.openclaw/secrets/secrets.py", "get", "valr_api_secret"]).decode().strip()
    return key, secret

def valr_get(path, key, secret):
    ts = str(int(time.time() * 1000))
    sig = hmac.new(secret.encode(), (ts + "GET" + path).encode(), hashlib.sha512).hexdigest()
    resp = requests.get(f"https://api.valr.com{path}", headers={
        "X-VALR-API-KEY": key,
        "X-VALR-SIGNATURE": sig,
        "X-VALR-TIMESTAMP": ts
    })
    resp.raise_for_status()
    return resp.json()

def main():
    key, secret = get_creds()
    pair = "SOLUSDTPERP"
    
    # Get positions
    positions = valr_get(f"/v1/positions/open?currencyPair={pair}", key, secret)
    
    # Get orders
    orders = valr_get(f"/v1/orders/open?currencyPair={pair}", key, secret)
    
    # Calculate exposure
    pos_qty = 0.0
    for p in positions:
        qty = float(p['quantity'])
        pos_qty += qty if p['side'] == 'buy' else -qty
    
    bid_qty = sum(float(o['originalQuantity']) for o in orders if o['side'] == 'buy')
    ask_qty = sum(float(o['originalQuantity']) for o in orders if o['side'] == 'sell')
    
    net = pos_qty + bid_qty - ask_qty
    hedged = abs(net) < 0.01
    
    print(f"Position: {pos_qty:.4f} {pair}")
    print(f"Bids:     {bid_qty:.4f}")
    print(f"Asks:     {ask_qty:.4f}")
    print(f"Net:      {net:.4f}")
    print(f"Hedged:   {'✅ Yes' if hedged else '❌ NO'}")
    
    if not hedged:
        print(f"\n⚠️  Book is UNHEDGED by {net:.4f}")
        return 1
    return 0

if __name__ == "__main__":
    exit(main())
