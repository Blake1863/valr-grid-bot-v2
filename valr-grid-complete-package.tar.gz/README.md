# VALR Grid Bot + Backtester — Complete Package

This package provides everything needed to **optimize** and **deploy** a grid trading bot for VALR perpetual futures.

## What's Included

```
valr-complete-package/
├── valr-futures-grid-bot/       # The trading bot
│   ├── src/main.rs              # Bot source (Rust)
│   ├── Cargo.toml
│   ├── config/example.json
│   ├── scripts/check_exposure.py
│   ├── systemd/valr-grid-bot.service
│   └── docs/TROUBLESHOOTING.md
│
├── grid-backtester/             # Optimization tool
│   ├── backtest.py              # Backtest engine (Python)
│   ├── requirements.txt
│   └── results/                 # Sample results
│
└── README.md                    # This file
```

## Workflow: Optimize → Deploy → Monitor

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  1. BACKTEST    │────▶│  2. DEPLOY      │────▶│  3. MONITOR     │
│                 │     │                 │     │                 │
│ Run backtester  │     │ Build & run bot │     │ Check exposure  │
│ Test parameters │     │ systemd service │     │ View logs       │
│ Find optimal    │     │ Auto-healing    │     │ Adjust if needed│
└─────────────────┘     └─────────────────┘     └─────────────────┘
```

---

## Step 1: Backtest (Optimize Parameters)

**Goal:** Find the best grid parameters for your chosen pair.

### Setup

```bash
cd grid-backtester
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### Run Backtest

```bash
# Default: SOLUSDTPERP, 14 days, 15-min candles
python3 backtest.py

# Custom pair
python3 backtest.py --pair BTCUSDTPERP

# Custom period
python3 backtest.py --days 30
```

### Understand Results

The backtester outputs (SOLUSDTPERP, 14 days):

```
🏆 BEST BY SHARPE (risk-adjusted):
   Levels: 5 | Spacing: 1.0%
   PnL: $1,474 | DD: 0.0% | Sharpe: 3.03 | Fills: 22

💰 BEST BY RAW PnL:
   Levels: 3 | Spacing: 0.3%
   PnL: $7,366 | DD: 0.0% | Sharpe: 0.99 | Fills: 251

⚡ BEST MODERATE (Sharpe >1, max PnL):
   Levels: 3 | Spacing: 0.4%
   PnL: $7,281 | DD: 0.0% | Sharpe: 1.18 | Fills: 166
```

**Key metrics:**
- **Sharpe ratio** — Risk-adjusted returns (higher = better, >1.0 is good)
- **PnL** — Total profit/loss over the period
- **Drawdown** — Max peak-to-trough decline (capped at 100%)
- **Fills** — Number of trades executed

### Recommended Profiles

| Profile | Levels | Spacing | PnL (14d) | Sharpe | Fills | Best For |
|---------|--------|---------|-----------|--------|-------|----------|
| Conservative | 5 | 1.0% | +$1,474 | 3.03 | 22 | Safety, low activity |
| **Moderate** | **3** | **0.4%** | **+$7,281** | **1.18** | **166** | **Balanced (default)** |
| Aggressive | 3 | 0.3% | +$7,366 | 0.99 | 251 | Max PnL, high activity |

**Default:** Moderate — highest PnL with Sharpe >1.0 (best risk-adjusted returns)

### Safety Features

**Unhedged Protection:**
- Health check detects book imbalance every 5 min
- If unhedged: cancels all orders, places SL + TP conditional orders
- **Conditional TP** (not limit order) — auto-cancels when SL triggers
- Prevents unwanted fills after stop-out if price reverses

### Update Config

Edit `valr-futures-grid-bot/config/example.json`:

```json
{
  "pair": "SOLUSDTPERP",
  "leverage": 5,
  "balance_usage_pct": 90.0,
  "levels": 4,              // From backtest
  "spacing_pct": 1.0,       // From backtest
  "max_loss_pct": 3.0
}
```

---

## Step 2: Deploy (Build & Run Bot)

### Build

```bash
cd valr-futures-grid-bot
cargo build --release
```

### Configure

```bash
# Copy example config
cp config/example.json config.json

# Edit with your optimized parameters
nano config.json
```

### Deploy with systemd

```bash
# Copy service file
cp systemd/valr-grid-bot.service ~/.config/systemd/user/

# Reload systemd
systemctl --user daemon-reload

# Enable & start
systemctl --user enable valr-grid-bot.service
systemctl --user start valr-grid-bot.service

# Check status
systemctl --user status valr-grid-bot.service
```

### Verify Running

```bash
# View logs
journalctl --user -u valr-grid-bot.service -f

# Check exposure
python3 scripts/check_exposure.py
```

Expected output:
```
Position: -1.7400 SOLUSDTPERP
Bids:      1.7400
Asks:      0.0000
Net:       0.0000
Hedged:    ✅ Yes
```

---

## Step 3: Monitor (Ongoing)

### Daily Checks

```bash
# Bot status
systemctl --user status valr-grid-bot.service

# Recent logs
journalctl --user -u valr-grid-bot.service -n 50

# Book balance
python3 scripts/check_exposure.py
```

### Weekly Optimization

Market conditions change. Re-run backtester weekly:

```bash
cd ../grid-backtester
source venv/bin/activate
python3 backtest.py --days 7  # Last 7 days

# Compare with current config
# If new params are significantly better, update config.json and restart bot
```

### When to Adjust

**Re-optimize if:**
- Backtest shows significantly better Sharpe ratio (>20% improvement)
- Market volatility changed dramatically
- Bot is consistently unhedged (check logs)

**Restart bot after config change:**
```bash
systemctl --user restart valr-grid-bot.service
```

---

## Parameter Guide

| Parameter | Effect | Typical Range |
|-----------|--------|---------------|
| `levels` | More levels = more orders, tighter grid | 3-6 |
| `spacing_pct` | Wider = fewer fills, less risk | 0.25-1.0% |
| `leverage` | Higher = more exposure, more risk | 3-5x |
| `max_loss_pct` | Stop-loss distance from entry | 2-5% |
| `balance_usage_pct` | % of capital to deploy | 80-90% |

### Trade-offs

**Tight grid (low spacing, high levels):**
- ✅ More fills, more profit potential
- ❌ More risk if trend moves against you

**Wide grid (high spacing, low levels):**
- ✅ Safer, less capital at risk
- ❌ Fewer fills, slower profit

**Backtester helps you find the sweet spot.**

---

## Troubleshooting

### Backtester Issues

**Rate limited (429):**
- VALR public endpoints: 30 req/min
- Backtester auto-retries with backoff
- Wait a few minutes, try again

**Not enough data:**
- Ensure pair has sufficient history
- Try reducing `--days` parameter

### Bot Issues

See `valr-futures-grid-bot/docs/TROUBLESHOOTING.md`

Common fixes:
```bash
# Restart bot
systemctl --user restart valr-grid-bot.service

# Check logs
journalctl --user -u valr-grid-bot.service -f

# Verify exposure
python3 scripts/check_exposure.py
```

---

## Example: Full Workflow

```bash
# 1. Backtest
cd grid-backtester
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
python3 backtest.py --pair SOLUSDTPERP --days 14
# Output: Best Sharpe = 4 levels, 1.0% spacing

# 2. Configure bot
cd ../valr-futures-grid-bot
cp config/example.json config.json
# Edit config.json: levels=4, spacing_pct=1.0

# 3. Build
cargo build --release

# 4. Deploy
cp systemd/valr-grid-bot.service ~/.config/systemd/user/
systemctl --user daemon-reload
systemctl --user enable valr-grid-bot.service
systemctl --user start valr-grid-bot.service

# 5. Verify
systemctl --user status valr-grid-bot.service
python3 scripts/check_exposure.py
journalctl --user -u valr-grid-bot.service -f
```

---

## Risk Warnings

⚠️ **Trading involves substantial risk of loss.**

- Test with small capital first
- Monitor daily
- Backtests are not guarantees of future performance
- Market conditions change — re-optimize regularly
- Never deploy more than you can afford to lose

---

## Support

- VALR API docs: https://api-docs.rooibos.dev/
- OpenClaw docs: https://docs.openclaw.ai

---

## License

MIT — Use at your own risk.
