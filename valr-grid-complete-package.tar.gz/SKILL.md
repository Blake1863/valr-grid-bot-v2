---
name: valr-grid-complete
description: Complete VALR grid trading system with backtester for optimization and bot for live deployment. Use backtester to find optimal parameters, then deploy grid bot with those settings.
---

# VALR Grid Bot + Backtester — Complete System

Two tools, one workflow: **optimize** then **deploy**.

## Components

### 1. Grid Backtester (`grid-backtester/`)

Python tool to test grid parameters against historical data.

**Features:**
- 15-min OHLCV buckets from VALR
- 0.04% taker fee modeled
- 10bps slippage modeled
- Tests 500+ parameter combinations
- Outputs: optimal levels, spacing, stop-loss

**Usage:**
```bash
cd grid-backtester
pip install -r requirements.txt
python3 backtest.py --pair SOLUSDTPERP --days 14
```

**Output:**
```
🏆 BEST BY SHARPE: Levels=4, Spacing=1.0%, Sharpe=3.03
💰 BEST BY PnL:    Levels=3, Spacing=0.4%, PnL=$7,260
```

### 2. Grid Bot (`valr-futures-grid-bot/`)

Rust trading bot that executes the grid strategy.

**Features:**
- Native VALR stop-loss orders
- Book reconciliation (hedge check)
- systemd auto-healing
- Hot config reload (5 min)
- POST-only orders (0% maker fee)

**Usage:**
```bash
cd valr-futures-grid-bot
cargo build --release
cp config/example.json config.json  # Edit with backtest results
systemctl --user start valr-grid-bot.service
```

## Workflow

```
1. BACKTEST          2. DEPLOY           3. MONITOR
   ↓                    ↓                   ↓
python3 backtest.py  cargo build        journalctl -f
levels=4, spacing=1%  systemctl start   check_exposure.py
   ↓                    ↓                   ↓
edit config.json     bot runs          re-optimize weekly
```

## Key Files

| File | Purpose |
|------|---------|
| `grid-backtester/backtest.py` | Run backtests |
| `grid-backtester/results/` | Historical results |
| `valr-futures-grid-bot/src/main.rs` | Bot source |
| `valr-futures-grid-bot/config/example.json` | Bot config template |
| `valr-futures-grid-bot/scripts/check_exposure.py` | Verify hedge |
| `valr-futures-grid-bot/systemd/valr-grid-bot.service` | Auto-heal service |

## Configuration

### Backtest Config (CLI)

```bash
python3 backtest.py --pair SOLUSDTPERP --days 14
```

| Arg | Default | Description |
|-----|---------|-------------|
| `--pair` | SOLUSDTPERP | VALR futures pair |
| `--days` | 14 | Historical period |

### Bot Config (`config.json`)

```json
{
  "pair": "SOLUSDTPERP",
  "leverage": 5,
  "balance_usage_pct": 90.0,
  "levels": 3,              // Moderate profile
  "spacing_pct": 0.4,       // Moderate profile (Sharpe >1, max PnL)
  "max_loss_pct": 3.0
}
```

**Recommended Profiles (SOLUSDTPERP, 14-day backtest):**

| Profile | Levels | Spacing | PnL | Sharpe | Fills |
|---------|--------|---------|-----|--------|-------|
| Conservative | 5 | 1.0% | +$1,474 | 3.03 | 22 |
| **Moderate** | **3** | **0.4%** | **+$7,281** | **1.18** | **166** |
| Aggressive | 3 | 0.3% | +$7,366 | 0.99 | 251 |

## Health Checks

### Bot Status

```bash
systemctl --user status valr-grid-bot.service
```

### Book Balance

```bash
python3 valr-futures-grid-bot/scripts/check_exposure.py
# Net: 0.0000, Hedged: ✅ Yes
```

### Logs

```bash
journalctl --user -u valr-grid-bot.service -f
```

## Troubleshooting

### Bot Crashed

```bash
systemctl --user restart valr-grid-bot.service
journalctl --user -u valr-grid-bot.service -n 50
```

### Book Unhedged

Bot auto-fixes: cancels orders, places SL, places closing order.

Check logs for `⚠️ BOOK IS UNHEDGED` — bot handles it automatically.

### Backtest Rate Limited

VALR public endpoints: 30 req/min. Backtester auto-retries. Wait 1-2 min.

## References

- VALR API: https://api-docs.rooibos.dev/
- Workspace: `/home/admin/.openclaw/workspace/`
